Este é o repositório do primeiro projeto da disciplina IF668 - Introdução à Computação, no primeiro semestre de 2018. 
